public class J1 {
    public static void main(String[] args){
        int score =95;
        double gpa = 3.85;
        boolean isloggeddIn = false;
        String username = "john_doe"; 
    }
}