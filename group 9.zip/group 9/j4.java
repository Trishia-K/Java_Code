public class j4 {
    // Primitive types store the actual value in memory.
    // and 
 // Reference types store a memory address to an object, not the actual
}
