public class j7 {
    
    public static void main(String[] args){
    int a = 20;
    int b = 3;
    int c= 4;
    int answer =a-b*c/2+1;
    System.out.println(answer);    
    }
}
