public class J2 {
    public static void main(String[] args){
         // population of the city = int 
        // A single letter grande = char
        // result of a true/false = boolean
        // the exact amount of chemical in grams = double
    }
}
-