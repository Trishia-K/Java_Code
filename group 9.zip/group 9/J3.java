public class J3 {
    public static void main(String[] args){
       int a = 10;
         int b = 3;

        double result = (double)a / b;
         System.out.println(result);
    




     double val = 45.78;
     int intResult = (int) val;
     System.out.println("the answer would be: " + intResult);


    char initial = 'A';
    int charResult = (int) initial;
    System.out.println(charResult);
    }

}