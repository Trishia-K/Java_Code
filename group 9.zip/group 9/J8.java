public class J8 {
    // expression is a combination of variables, constants, operators, and method calls that the Java compiler can evaluate to produce a single value.
    
    // Expression that evaluates to an integer value
     int x = 10;
     int y = 5;
    int result = x + y * 2;   


    // Expression that evaluates to an boolean value
    int age = 18;
    boolean canVote = age >= 18;   


}
