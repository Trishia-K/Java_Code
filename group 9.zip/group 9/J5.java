public class J5 {
    public static void main(String[] args) {
        int x = 15;
        x += 5;
        x/=4;
        x++;
        x%=3;
        
        System.out.println(x);
    }
}
