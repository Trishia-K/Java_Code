public class J6 {
    
    public static void main(String[] args){
        int p = 5;
        int q = 8;
        boolean sunny = false;
        
        // 1 p < q && !sunny

        // answer: true

        // 2. q % 2 == 0 || p > 10

        // answer: true

         // 3. !(p == 5) && (q != 8)

        // answer: false

        // 4. q / 4 > 1

        // answer: true
    }

}
